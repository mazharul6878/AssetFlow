# AssetFlow UI Theme Kit

This pack contains two reference mockup images, reusable PNG background/surface assets, a consistent transparent PNG icon set, and a detailed Markdown specification/master prompt.

Start here:
1. Read `AssetFlow_UI_Theme_Specification_and_Google_AI_Studio_Prompt.md`.
2. Upload both files from `references/` to Google AI Studio as visual references.
3. Upload this Markdown file and the assets ZIP contents if the workflow supports file attachments.
4. Tell the AI to inspect the existing project first and preserve all existing app/business logic.

Accuracy note: The reference images are flattened mockups. The supplied icons and elements are style-matched reusable approximations, not original editable source assets from the mockup renderer.
