# AssetFlow — Aurora Light UI Theme Kit & Google AI Studio Master Prompt

**Version:** 1.0  
**Purpose:** Reproduce the visual direction of the two supplied AssetFlow UI reference images across the existing Android application.

## 1. What is included

- `references/reference_light_theme_all_pages.png` — light-theme screen collage reference.
- `references/reference_welcome_role_selection_flow.png` — welcome, role-selection and onboarding flow reference.
- `assets/backgrounds/` — high-resolution light gradient backgrounds.
- `assets/icons/` — transparent PNG line-icon set.
- `assets/elements/assetflow_mark_transparent_512.png` — reusable abstract AssetFlow mark approximation.
- `assets/elements/glass_card_surface.png` — reusable glass-card surface reference.
- `assets/elements/primary_button_surface.png` and `secondary_button_surface.png` — button surface references.
- `assets/elements/color_palette_reference.png` — palette reference.

**Important accuracy note:** The reference images are flattened mockup collages, not original editable design files. The included icons and visual elements are reusable approximations made to match their style; they are not guaranteed to be the exact source vectors used to render the collages. Use the reference images as visual guidance and implement actual controls, text, icons, shadows, and surfaces natively in the app rather than using the full collage as a screen background.

## 2. Product and implementation context

Application: **AssetFlow**, a fixed-asset verification and counting application.

The existing application is being built in Google AI Studio Build Mode. Preserve the current approved architecture, business rules, Firebase integration, Google Drive integration, existing data, and all approved features. This is a UI implementation request, not permission to rebuild the application or change its backend architecture.

The two supplied reference images are the visual source of truth for:
- pale blue/white background;
- bright blue primary actions;
- soft depth and layered surfaces;
- glassmorphism/neumorphism blend;
- rounded cards and controls;
- subtle purple/cyan accent gradients;
- clean corporate typography;
- spacious, highly legible mobile layouts.

Do not copy accidental spelling errors or placeholder data from the mockups. Use real labels from the existing functional specification.

## 3. Visual design system

### 3.1 Theme name
**AssetFlow Aurora Light — Soft Depth Glass**

### 3.2 Suggested palette
Use these as starting design tokens, adjusting only when needed for accessibility and consistency:

| Token | Hex | Use |
|---|---|---|
| `background` | `#F6F8FF` | Main screen background |
| `backgroundTint` | `#E7EEFF` | Lower gradient / ambient tint |
| `surface` | `#FFFFFF` | Main cards and form surfaces |
| `surfaceGlass` | `#FFFFFF` with 78–90% opacity | Glass-like panels |
| `primary` | `#147DFF` | Main CTA, selected navigation, links |
| `primaryDeep` | `#0758D6` | CTA gradient end / pressed state |
| `sky` | `#65C9FF` | Soft highlights |
| `violet` | `#7768F8` | Secondary accent |
| `mint` | `#20C997` | Success and completed status |
| `amber` | `#FFB547` | Pending / warning status |
| `rose` | `#F05D7A` | Failure / destructive status |
| `textPrimary` | `#172A4A` | Titles and primary content |
| `textSecondary` | `#61718F` | Supporting text |
| `borderSoft` | `#DDE6F7` | Subtle outlines |
| `iconMuted` | `#8092B4` | Secondary icons |

Use semantic colors consistently. Never rely on color alone to communicate status; include text or icons.

### 3.3 Background treatment
- Use a very light blue-to-white gradient, not a flat gray background.
- Add subtle blurred blue/violet ambient glows only near the edges or behind major hero content.
- Keep the background low contrast so forms and text remain easy to read.
- Avoid strong patterns, noisy textures, excessive particles, or dark backgrounds in this Light theme.
- Use the provided PNG backgrounds as visual references or decorative layers; do not stretch them into every component.

### 3.4 Soft depth and glass surfaces
Create depth through a restrained combination of:
- white or near-white surfaces;
- soft blue-gray shadows with low opacity;
- thin, pale blue borders;
- subtle top-edge highlights;
- 18–28 dp card corner radii;
- 12–18 dp control corner radii;
- small elevation differences between page background, cards, floating controls, and primary actions.

Avoid heavy black shadows, excessive blur, thick borders, or a skeuomorphic look. Depth should be visible but elegant.

Recommended implementation starting points:
- Card elevation: 3–8 dp, adjusted by hierarchy.
- Border: 1 dp, `borderSoft`.
- Card padding: 16–20 dp.
- Primary button height: 48–54 dp.
- Touch target: at least 48 × 48 dp.
- Screen horizontal padding: 16–20 dp.
- Spacing scale: 4, 8, 12, 16, 20, 24, 32 dp.

### 3.5 Typography
- Use a modern sans-serif typeface available in the existing Android project.
- Screen title: 22–28 sp, semibold/bold.
- Section title: 16–18 sp, semibold.
- Body: 14–16 sp.
- Helper text and metadata: 12–14 sp, with adequate contrast.
- Keep headings and button labels concise.
- Avoid text clipping, tiny labels, and excessive uppercase text.

### 3.6 Buttons and inputs
Primary button:
- Blue gradient or solid `primary`.
- White semibold label.
- Rounded corners, soft blue shadow, subtle top highlight.
- Visible pressed, disabled, loading, and error states.

Secondary button:
- White surface, thin soft border, dark-blue text.
- Low-elevation shadow where appropriate.

Text input:
- White or translucent-white surface.
- Subtle blue-gray outline.
- Clear label and placeholder contrast.
- Correct keyboard type, password visibility control, focus state, validation state, and error text.
- Never use placeholder text as the only field label.

### 3.7 Icons and illustrations
- Use a consistent line-icon family, similar in weight and visual scale to the reference.
- Use the included transparent PNG icons only for decorative or reference purposes where raster images are appropriate.
- For interactive Android controls, prefer native vector/drawable resources or the project's existing icon library so icons scale crisply and can respond to state.
- Avoid mixing filled, outline, emoji, and unrelated icon families.
- Use blue as the default icon color, with restrained violet, cyan, mint, amber, and rose accents.
- Illustrations should be minimal, friendly, and corporate; avoid adding new illustrations to every screen.

## 4. Required screen inventory and visual treatment

Use the original AssetFlow functional specification to confirm the definitive screen list and required behaviour. At minimum, apply the theme consistently to these screens wherever they exist in the approved plan:

1. **Welcome / Splash** — centered AssetFlow mark, title, concise product value statement, subtle office/asset illustration, trust/value indicators, primary Get Started action.
2. **Role Selection** — two role cards only: Admin and Auditor. Each card includes a clear icon, role title, short description, and selection state. Do not present Owner as a self-selectable role.
3. **Login** — email/password, password visibility, remember-me only if approved, forgot-password flow, Google sign-in only if configured, sign-up navigation.
4. **Registration** — approved registration fields, validation, terms/privacy acknowledgement if required, and account-creation status.
5. **Client Selection** — search, clear client cards, selection indicator, next action. Only show clients the authenticated user is permitted to access.
6. **Fiscal Year Selection** — fiscal-year cards, date range, selected state, next action.
7. **Admin Home** — approved KPI cards, pending reviews, activity, synchronization status, and navigation to authorized Admin modules.
8. **Auditor Home** — assigned asset/counting summary, progress indicator, pending/draft totals, recent activity, and counting navigation.
9. **Asset Search** — search by permitted asset identifiers, clear results, filter controls, and useful empty/loading states.
10. **Asset Details** — asset identity, description, class, location and other approved register fields, plus Start Counting action.
11. **Counting Form** — all fields and the exact approved schema/mapping; labels, required markers, dropdowns, found/not-found choice, remarks, Save Draft and Submit actions.
12. **Photo Evidence** — image preview, thumbnail list, add/retake/remove actions only where approved, permission-aware capture and storage state.
13. **Submission Success** — confirmation icon, submission reference and timestamp when available, and a clear next action.
14. **Auditor Activity / My Submissions** — draft/submitted/returned/approved states with labels and timestamps.
15. **Admin Review List** — pending/approved/returned/rejected filters as defined in the functional plan, search, and submission summaries.
16. **Review Details** — asset and submission data, evidence, audit metadata, and authorized review actions.
17. **Resources** — Asset Register, Master Input workbook, field mapping, and document resources only as specified in the approved plan.
18. **Field Mapping** — source register header → Auditor-facing label/input → Master Input destination column.
19. **Control Panel** — authorized user/role management, client assignment, access requests, Drive settings, and other approved controls.
20. **User Management** — user identity, authorized role and assignment state, with actions visible only when permitted.
21. **Access Requests** — pending/all filters, requester and client details, and authorized approve/reject actions.
22. **Settings** — theme, language, notifications, and about information only where implemented and approved.
23. **Profile** — user information, edit profile, change password, and logout where supported.

If the existing specification includes additional pages, style those pages using the same design tokens. Do not omit any required page simply because it is not pictured.

## 5. Role Selection page — specific requirements

The Welcome screen must navigate to a dedicated Role Selection screen.

### Layout
- Pale blue/white gradient background.
- Small back navigation at the top.
- Heading: “Select Your Role”.
- Supporting text: “Choose your role to continue”.
- Two large rounded cards stacked vertically:
  - **Auditor** — “Perform asset counting and submit reports”.
  - **Admin** — “Manage clients, review submissions and settings”.
- Use a person/checklist-style icon for Auditor and a shield/briefcase-style icon for Admin.
- Selected card: blue outline, subtle blue glow, visible check indicator, and accessible selected state.
- Unselected card: white/glass surface, thin border, restrained shadow.
- Primary “Continue” button near the bottom.
- Keep spacing and alignment consistent with the other screens.

### Security and business rules
- Role selection is a UI preference or entry-flow choice; it is not an authorization grant.
- The backend must derive or verify the user's actual role and permissions.
- A user must never gain Admin privileges by selecting Admin in the UI.
- Owner governance remains backend-controlled and is not a selectable registration role.
- An authenticated unassigned Auditor may sign in, but must not access client data until assigned; provide the approved access-request flow.
- Follow the approved registration and login policy in the authoritative functional plan. Do not invent a new access policy while styling the screen.

## 6. Navigation and interaction consistency

- Keep top bars, back navigation, bottom navigation, card styles, icon sizes, field spacing, and primary actions consistent.
- Preserve the existing navigation graph unless a change is required by the approved specification.
- Use clear page titles and preserve the selected client/fiscal-year context where required.
- Disable actions only when their business rules require it, and explain why.
- Provide inline loading, empty, error, success, and permission-denied states.
- Avoid repeated popups; prefer calm inline messages for unassigned users and pending requests.
- Do not make decorative mock controls appear functional if no corresponding workflow exists.

## 7. Accessibility and responsive behaviour

- Maintain readable text contrast against light surfaces.
- Support system font scaling without clipping.
- Provide semantic labels/content descriptions for interactive icons.
- Ensure tap targets are at least 48 dp.
- Make form errors understandable and close to the relevant field.
- Keep the same visual language across small and large Android screens.
- Avoid hardcoded screen coordinates or layouts that only work at one resolution.

## 8. Implementation constraints

1. First inspect the existing source code and identify the current UI framework, theme files, navigation, reusable components, and screen implementations.
2. Implement the theme using the project's existing architecture; do not replace the app architecture solely to match the image.
3. Create shared theme tokens and reusable components for background, cards, buttons, inputs, chips, status badges, and navigation.
4. Refactor screens to use the shared design system instead of introducing one-off styles.
5. Use real app data and existing backend flows; do not hardcode the mockup's sample companies, assets, users, dates, counts, or statuses.
6. Preserve all Firebase, Firestore, authorization, Google Drive, Master Input workbook, evidence, and audit-history requirements.
7. Do not change Firestore schema, security rules, OAuth model, or privileged backend logic as part of a visual-only change unless separately justified and approved.
8. Do not delete existing features or data.
9. Do not claim that a page is implemented if it is only a placeholder.
10. Record bugs and missing items in the existing consolidated issue register for the final bug-fixing phase. Do not create a separate testing roadmap.
11. Do not deploy to production or perform destructive actions without explicit authorization.

## 9. Definition of done for the UI implementation

The UI theme implementation is complete when:
- all required existing screens use the shared Aurora Light visual system;
- backgrounds, cards, controls, icons, typography, spacing, and shadows are visually consistent;
- Welcome is followed by the required Role Selection page;
- Admin and Auditor screens respect their authorized workflows;
- forms retain all required fields and mapping;
- responsive layouts avoid clipping and overlapping;
- visual assets are stored in the appropriate project resource directories;
- existing business logic and backend integration are preserved;
- incomplete work and known issues are documented honestly.

This definition is an implementation acceptance checklist, not a separate testing roadmap.

---

# 10. Master Prompt for Google AI Studio

You are modifying the existing AssetFlow Android application. Implement a complete, consistent **AssetFlow Aurora Light — Soft Depth Glass** UI theme using the two attached reference images and the included `AssetFlow_UI_Theme_Kit.zip` assets.

The reference images are the visual target. Match their overall visual language as closely as practical: light blue/white gradient backgrounds, bright blue primary actions, subtle cyan/violet ambient accents, glass-like white cards, soft layered shadows, thin pale borders, rounded corners, clean corporate typography, and consistent line icons.

Before editing, inspect the current project and identify the UI framework, theme files, navigation graph, screen files, shared components, resources, and existing business logic. Then implement the theme inside the existing architecture.

Create reusable theme tokens and shared components. Apply them to every existing screen required by the approved AssetFlow functional specification, including Welcome, Role Selection, Login, Registration, Client Selection, Fiscal Year Selection, Admin Home, Auditor Home, Asset Search, Asset Details, Counting Form, Photo Evidence, Submission Success, Activity, Review, Review Details, Resources, Field Mapping, Control Panel, User Management, Access Requests, Settings, and Profile. Include any other pages required by the authoritative specification.

The Welcome page must navigate to a dedicated Role Selection page. The Role Selection page has exactly two selectable entry options: Admin and Auditor. Do not expose Owner as a self-selectable role. Role selection must never grant permissions. Actual roles and permissions must be verified by the existing trusted backend. Unassigned Auditors may authenticate but must not access client data until assigned.

Use the provided assets as reference resources. Implement native, responsive controls rather than setting a flattened reference collage as a screen background. Prefer vector/native icons for interactive controls; use the supplied PNGs for appropriate decorative assets. If an exact original asset is not available, create a visually consistent equivalent rather than pretending the asset is identical.

Use real existing application data and business rules. Do not hardcode sample values from the reference images. Preserve all approved features, navigation, Firebase Authentication, Firestore paths and rules, trusted backend authorization, Google Drive integration, Master Input workbook update logic, evidence storage, submission/approval states, and audit history.

Do not rebuild the app from scratch, replace the backend, change the database schema, remove features, delete data, or modify production configuration as part of the visual redesign. If a technical change is unavoidable, explain its reason and scope before proceeding.

Implement the theme in coherent steps: shared design tokens, background and surfaces, reusable components, navigation consistency, then screen-by-screen styling. Keep the implementation traceable to the existing source files. At completion, summarize changed files, screens covered, reusable components added, unresolved dependencies, and known issues to be addressed in the existing final bug-fixing phase. Do not create a separate testing roadmap and do not claim unverified work is complete.

Begin by auditing the current project and the two references, then implement the UI theme without interrupting the existing application build unnecessarily.
