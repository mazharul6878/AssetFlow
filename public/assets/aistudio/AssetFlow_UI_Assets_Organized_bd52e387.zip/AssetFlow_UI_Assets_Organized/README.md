# AssetFlow UI Assets — Organized

Aurora Light — Soft Depth Glass. Companion to `AssetFlow_Google_AI_Studio_UI_Implementation_Spec.md`, `AssetFlow_Design_Tokens.md` and `AssetFlow_UI_Asset_Inventory.md`.

## Folders

| Folder | What it is | Goes where |
|---|---|---|
| `00_originals/` | The supplied kit, byte-for-byte, original names | Keep for reference. Not shipped in the app. |
| `01_references/` | The two reference mockups | Upload to Google AI Studio as visual references. Never inside the app. |
| `android_res/drawable/` | 67 vector icons `ic_af_*.xml` | `app/src/main/res/drawable/` (native Android) |
| `android_res/drawable-nodpi/` | Background WebPs | `res/drawable-nodpi/` |
| `android_res/mipmap-*/` | Launcher icon, round icon, adaptive layers | `res/mipmap-*/` |
| `android_res/mipmap-anydpi-v26/` | Adaptive icon XML | `res/mipmap-anydpi-v26/` |
| `svg/icons/` | 67 SVG icons, `currentColor` | Web / PWA / hybrid: `public/assets/icons/` |
| `svg/brand/`, `png/brand/` | Logo mark (approximation) | Splash, Welcome, Login header |
| `svg/illustrations/`, `png/illustrations/` | Welcome hero (approximation) | Welcome screen only |
| `png/icons/{blue,white,muted,navy}/` | PNG icons, 48/96/192 px | Only where vectors cannot be used |
| `png/backgrounds/`, `webp/backgrounds/` | Three backgrounds at 1440, 1080, 720 px wide | Web: `public/assets/backgrounds/` |
| `png/launcher/` | 1024 and 512 store icons, favicons | Play listing, web manifest |
| `tokens/` | CSS variables, Android `af_colors.xml`, Compose `AssetFlowColors.kt`, JSON | Theme layer |

Use the Android set in a native Android project and the SVG/CSS set in a web or hybrid project. Do not mix icon families.

## Accuracy notes

- The reference images are flattened mockups. The logo mark, welcome hero and all icons here are re-creations in the same style, not the original source files.
- The logo mark is traced from the kit PNG (the same shapes and colours). The welcome hero is simpler than the mockup's.
- Icon geometry follows the open-source Lucide convention (ISC licence), redrawn for this kit.
- Backgrounds were regenerated because the supplied ones had grey halos around the glows.
- The Google "G" logo, product photos, avatars and client logos are not included. See the inventory for the full list of missing assets.
